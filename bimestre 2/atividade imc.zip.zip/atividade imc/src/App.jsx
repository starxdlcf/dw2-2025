import './App.css'
import Calculadora from'./Calculadora'

function App() {
  return(
    <div className="main">
      <h1>Calculadora IMC</h1>
          <Calculadora/>
    </div>
  )
}

export default App
